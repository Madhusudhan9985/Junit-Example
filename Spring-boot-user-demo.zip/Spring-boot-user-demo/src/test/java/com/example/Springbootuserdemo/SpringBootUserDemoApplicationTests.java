package com.example.Springbootuserdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootUserDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
