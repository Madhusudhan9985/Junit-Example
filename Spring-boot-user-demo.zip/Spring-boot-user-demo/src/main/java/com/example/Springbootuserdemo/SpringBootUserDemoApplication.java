package com.example.Springbootuserdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootUserDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootUserDemoApplication.class, args);
	}

}
